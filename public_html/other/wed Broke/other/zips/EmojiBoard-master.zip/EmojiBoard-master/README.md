EmojiBoard
==========

A quick way to access Emoji without having the keyboard turned on. [See the live version][live].

<img src="http://i.imgur.com/I7iecqP.jpg" width="320" height="568" />

[live]: http://josh-asch.net/emoji/
