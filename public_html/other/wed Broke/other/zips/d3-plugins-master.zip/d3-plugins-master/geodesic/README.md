# Geodesic Grid

Example: <http://bl.ocks.org/3057239>
