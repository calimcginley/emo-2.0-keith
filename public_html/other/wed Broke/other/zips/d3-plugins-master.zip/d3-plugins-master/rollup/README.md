# Rollup (PivotGraph) Layout 

Example: <http://bl.ocks.org/4343153>

The d3.rollup plugin implements the “PivotGraph” technique for collapsing large graphs along categorical dimensions, as described by Martin Wattenberg in [Visual Exploration of Multivariate Graphs](http://hint.fm/papers/pivotgraph.pdf).
