# Polyhedral Geographic Projections

Examples:

 * [Gnomonic Butterfly Map](http://www.jasondavies.com/maps/gnomonic-butterfly/)
 * [Waterman Butterfly Map](http://www.jasondavies.com/maps/waterman-butterfly/)
 * [Collignon Butterfly Map](http://www.jasondavies.com/maps/collignon-butterfly/)
