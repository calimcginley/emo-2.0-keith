# d3.longscroll

Scroll large numbers of rows using virtual rendering: <http://bl.ocks.org/3689677>

## Limitations

Currently, only up to around 1e7px of vertical space is supported in current
browsers. A fix for this is [in the works][1].

[1]: https://groups.google.com/d/msg/d3-js/vNOvn2YUcaI/mz7m1igScUUJ
