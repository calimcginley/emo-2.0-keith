<?php
header( 'Location: http://www.keithmcginley.com' ) ;
?>